<?php $table_name='food_demo';?>
<?php include("../../src/config/includes.php"); 
echo Body::bodyContain($table_name); 
include('../../src/layout/foot.php');
 ?>