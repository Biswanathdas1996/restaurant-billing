<?php $table_name='food_admin_push_notification';?><?php include("../../src/config/includes.php");
 echo Body::bodyContain($table_name);?>
<!--Write your code here-->
<?php include('../../src/layout/foot.php'); ?>