<?php 
header("Location: ./login");
?>